cbir
====

Content-based image retrieval. There is a database of images and you can use a sample image to search for similar images in the database using YIQ transformation.

A demo instance can be found at http://cbir.co.nf.

Database can be loaded from create.sql. A small collection of images is included.

Note: addfolder1.php was written for execution at a server without time limitations.
For a web host with time limitations addfolder.php is recommended.
