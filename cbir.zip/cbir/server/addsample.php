<?php

include('functions.php');

$filename = UploadImage("query");
  
header( 'Location: index.php?file='.$filename.'&page=1' ) ;

?>