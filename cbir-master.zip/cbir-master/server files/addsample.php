<?

include('functions.php');

UploadImage("query");
  
header( 'Location: index.php' ) ;

?>